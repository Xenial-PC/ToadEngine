﻿using ToadEngine.Classes.Base.Rendering.Object;

namespace $rootnamespace$;

public class $safeitemname$ : GameObject
{
    public override void Setup()
    {
        
    }
}
