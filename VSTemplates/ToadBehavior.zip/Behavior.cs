﻿using ToadEngine.Classes.Base.Scripting.Base;

namespace $rootnamespace$;

public class $safeitemname$ : Behavior
{
    public void Awake()
    {
        
    }

    public void Update()
    {
        
    }
	
    public void OnGUI()
    {
        
    }

    public void Dispose()
    {
       
    }
}
